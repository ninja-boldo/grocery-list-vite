// Minimal mobile component for unit tests only
import React from 'react';

export const RecipeBookMobile = () => {
  return <div data-testid="recipe-book-mobile">Mobile RecipeBook Component</div>;
};