import React from 'react';

export const RecipeCardWeb = (props: any) => {
  return <div data-testid="recipe-card-web">{props.children || 'Web Recipe Card'}</div>;
};