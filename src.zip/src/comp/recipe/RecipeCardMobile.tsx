import React from 'react';

export const RecipeCardMobile = (props: any) => {
  return <article data-testid="recipe-card-mobile">{props.children || 'Mobile Recipe Card'}</article>;
};