import React from 'react';

export const RecipeBookWeb = () => {
  return <div data-testid="recipe-book-web">Web RecipeBook Component</div>;
};