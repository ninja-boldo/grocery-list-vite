import { useEffect, useRef, useState, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Html5Qrcode } from "html5-qrcode";
import AppHeader from "@/comp/other/AppHeader";
import BottomTabBar from "@/comp/other/BottomTabBar";
import AuthPopup from "@/comp/other/AuthPopup";
import { authApiCall, hasStoredJwtToken } from "@/lib/authApi";

// ── Palette ─────────────────────────────────────────────────────────────────
const P = {
  bg: "#0D1117",
  surface: "#161b22",
  border: "#21262d",
  teal: "#1D9E75",
  tealD: "#0f2a28",
  tealB: "#0d948850",
  text: "#e6edf3",
  muted: "#6e7681",
  subtle: "#4d5566",
  red: "#ef4444",
  redD: "#2a1111",
  redB: "#ef444430",
} as const;

type ScanMode = "auto" | "manual";

type ScanResult = {
  ean?: string;
  itemName?: string;
  detail: string;
  known: boolean;
  count: number;
  isAdd: boolean;
  isWish: boolean;
};

// Pending product whose package quantity is unknown — triggers the quantity modal
type PendingQuantity = {
  ean: string;
  itemName: string;
};

const QUANTITY_UNITS = ["g", "kg", "ml", "L", "Stück", "cl", "EL", "TL"] as const;

export default function ImprovedScanner() {
  const navHook = useNavigate();
  const location = useLocation();

  const queryParams = new URLSearchParams(location.search);
  const count = queryParams.get("count") || "1";
  const isWishList = queryParams.get("wishlist") === "true";

  const [headline, setHeadline] = useState("");
  const [mode, setMode] = useState<ScanMode>("auto");
  const [ean, setEan] = useState("");
  const [manualEan, setManualEan] = useState("");
  const [manualName, setManualName] = useState("");
  const [manualQuantity, setManualQuantity] = useState(1);
  const [scanQuantity, setScanQuantity] = useState(1);
  const [inputMode, setInputMode] = useState<"ean" | "name">("name");
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string>("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [verbose, setVerbose] = useState(false);
  const [scanCount, setScanCount] = useState(0);
  const [lastScanTime, setLastScanTime] = useState<string>("");
  const [scannedCode, setScannedCode] = useState<string>("");
  const [needReauth, setNeedReauth] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);

  // ── Quantity modal state ──────────────────────────────────────────────────
  const [pendingQuantity, setPendingQuantity] = useState<PendingQuantity | null>(null);
  const [qtyAmount, setQtyAmount] = useState<string>("100");
  const [qtyUnit, setQtyUnit] = useState<string>("g");
  const [qtySaving, setQtySaving] = useState(false);

  const scanLockRef = useRef(false);
  const lastSentRef = useRef<{ ean?: string; ts?: number }>({});
  const html5QrCodeRef = useRef<Html5Qrcode | null>(null);
  const scannerIdRef = useRef("qr-reader");
  const quantityTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scanSubmitTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const resultTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const log = useCallback(
    (message: string, data?: unknown) => {
      if (verbose) {
        console.log(`[Scanner] ${message}`, data || "");
      }
    },
    [verbose],
  );

  useEffect(() => {
    if (!hasStoredJwtToken()) {
      setNeedReauth(true);
    }
  }, []);

  const handleNeedReauth = useCallback(() => {
    setNeedReauth(true);
    setError("Authentication required. Please sign in again.");
  }, []);

  const apiCall = useCallback(
    async <T,>(
      url: string,
      options: RequestInit = {},
      retries = 3,
      onUnauthorized?: () => void,
    ): Promise<T> =>
      authApiCall<T>(url, options, {
        retries,
        retryDelayMs: 300,
        onUnauthorized,
      }),
    [],
  );

  const showResult = useCallback((result: ScanResult) => {
    if (resultTimeoutRef.current) clearTimeout(resultTimeoutRef.current);
    setScanResult(result);
    resultTimeoutRef.current = setTimeout(() => setScanResult(null), 6000);
  }, []);

  // Save verified product quantity to the golden record endpoint
  const saveVerifiedProduct = useCallback(async () => {
    if (!pendingQuantity) return;
    const amount = parseFloat(qtyAmount);
    if (!isFinite(amount) || amount <= 0) return;

    setQtySaving(true);
    try {
      await apiCall(
        "/api/verified_products",
        {
          method: "POST",
          headers: { "Content-Type": "application/json; charset=UTF-8" },
          body: JSON.stringify({
            ean: pendingQuantity.ean,
            item_name: pendingQuantity.itemName,
            quantity: amount,
            unit: qtyUnit,
          }),
        },
        1,
        handleNeedReauth,
      );
    } catch (err) {
      console.error("Failed to save verified product:", err);
    } finally {
      setQtySaving(false);
      setPendingQuantity(null);
    }
  }, [apiCall, handleNeedReauth, pendingQuantity, qtyAmount, qtyUnit]);

  const hardStopCamera = async () => {
    const qr = html5QrCodeRef.current;
    if (!qr) return;
    try {
      if (qr.isScanning) await qr.stop();
      const videoElem = document.querySelector("video");
      const stream = videoElem?.srcObject as MediaStream | null;
      stream?.getTracks().forEach((track) => track.stop());
      if (videoElem) videoElem.srcObject = null;
    } catch (e) {
      console.warn("Hard stop failed:", e);
    } finally {
      html5QrCodeRef.current = null;
    }
  };

  const sendEan = useCallback(
    async (eanToSend: string, quantityToSend?: number) => {
      const now = Date.now();
      if (
        lastSentRef.current.ean === eanToSend &&
        now - (lastSentRef.current.ts || 0) < 1000
      ) {
        log("Skipping duplicate send for", eanToSend);
        return;
      }
      lastSentRef.current = { ean: eanToSend, ts: now };

      const parsedModeCount = Number(count);
      const finalCount = Number.isFinite(parsedModeCount) ? parsedModeCount : 1;
      const requestCount =
        typeof quantityToSend === "number" ? quantityToSend : finalCount;

      try {
        const data = await apiCall<{
          known_to_db?: boolean;
          detail?: string;
          item_name?: string;
          quantity_known?: boolean;
        }>(
          "/api/add_ean_to_list/",
          {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=UTF-8" },
            body: JSON.stringify({
              ean: eanToSend,
              count: requestCount,
              wish_list: String(isWishList),
            }),
          },
          1,
          handleNeedReauth,
        );

        if (
          data.known_to_db === true &&
          !(String(data.detail).toLowerCase() === "failed to add item")
        ) {
          setShowSuccess(true);
          setTimeout(() => setShowSuccess(false), 2500);
          showResult({
            ean: eanToSend,
            itemName: data.item_name,
            detail: data.detail ?? "Item processed successfully",
            known: true,
            count: requestCount,
            isAdd: requestCount > 0,
            isWish: isWishList,
          });
          // If the backend doesn't know the package quantity, ask the user
          if (data.quantity_known === false && data.item_name) {
            setPendingQuantity({ ean: eanToSend, itemName: data.item_name });
            setQtyAmount("100");
            setQtyUnit("g");
          }
        } else {
          setError("EAN not found in database");
          showResult({
            ean: eanToSend,
            detail: data.detail ?? "EAN not recognized",
            known: false,
            count: requestCount,
            isAdd: requestCount > 0,
            isWish: isWishList,
          });
          setTimeout(() => setError(""), 2500);
        }
      } catch (err) {
        if (err instanceof Error && err.message.includes("401")) return;
        setError("Network error");
        console.error("Network error:", err);
        setTimeout(() => setError(""), 2500);
      }
    },
    [apiCall, count, handleNeedReauth, isWishList, log, showResult],
  );

  const sendByName = useCallback(
    async (itemName: string, quantityToSend: number) => {
      try {
        await apiCall(
          "/api/add_ean_to_list/",
          {
            method: "POST",
            headers: { "Content-Type": "application/json; charset=UTF-8" },
            body: JSON.stringify({
              item_name: itemName,
              count: quantityToSend,
              wish_list: String(isWishList),
            }),
          },
          1,
          handleNeedReauth,
        );

        if ("vibrate" in navigator) {
          try { navigator.vibrate(200); } catch { /* ignore */ }
        }

        showResult({
          itemName,
          detail: `"${itemName}" added to ${isWishList ? "wish list" : "inventory"}`,
          known: true,
          count: quantityToSend,
          isAdd: true,
          isWish: isWishList,
        });
        setManualName("");
      } catch (err) {
        if (err instanceof Error && err.message.includes("401")) return;
        console.error("Error sending item:", err);
        setError("Failed to add item");
      }
    },
    [apiCall, handleNeedReauth, isWishList, showResult],
  );

  const handleQuantityChange = (delta: number, isScanner = false) => {
    if (isScanner) {
      setScanQuantity((prev) => Math.max(1, prev + delta));
    } else {
      setManualQuantity((prev) => Math.max(1, prev + delta));
      if (quantityTimeoutRef.current) clearTimeout(quantityTimeoutRef.current);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quantityTimeoutRef.current) clearTimeout(quantityTimeoutRef.current);

    if (inputMode === "ean") {
      if (manualEan && /^\d{8,14}$/.test(manualEan)) {
        sendEan(manualEan, manualQuantity);
      } else {
        setError("Please enter a valid barcode (8-14 digits)");
        setTimeout(() => setError(""), 2500);
      }
    } else {
      if (manualName.trim()) {
        sendByName(manualName.trim(), manualQuantity);
      } else {
        setError("Please enter an item name");
        setTimeout(() => setError(""), 3000);
      }
    }
  };

  useEffect(() => {
    return () => {
      if (quantityTimeoutRef.current) clearTimeout(quantityTimeoutRef.current);
      if (scanSubmitTimeoutRef.current) clearTimeout(scanSubmitTimeoutRef.current);
      if (resultTimeoutRef.current) clearTimeout(resultTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    const deleteFrom = isWishList ? "wish" : "item";
    const newHeadline = count === "1" ? `Add ${deleteFrom}` : `Remove ${deleteFrom}`;
    setHeadline(newHeadline);
    if (mode !== "auto") return;

    const startScanner = async () => {
      try {
        log("Initializing HTML5 QR Code scanner");
        const html5QrCode = new Html5Qrcode(scannerIdRef.current);
        html5QrCodeRef.current = html5QrCode;

        const config = { fps: 10, qrbox: { width: 250, height: 250 }, aspectRatio: 1.0 };

        const onScanSuccess = (decodedText: string) => {
          setScanCount((prev) => prev + 1);
          setLastScanTime(new Date().toLocaleTimeString());
          log("Scan success", decodedText);
          if (scanLockRef.current) return;
          scanLockRef.current = true;
          if (/^\d{8,14}$/.test(decodedText)) {
            setEan(decodedText);
            setScannedCode(decodedText);
            setScanning(false);
            setTimeout(() => { scanLockRef.current = false; }, 1000);
          } else {
            log("Invalid barcode format", decodedText);
          }
        };

        const onScanError = (errorMessage: string) => {
          if (verbose) log("Scan error (normal during scanning)", errorMessage);
        };

        try {
          await html5QrCode.start({ facingMode: "environment" }, config, onScanSuccess, onScanError);
          setScanning(true);
          setError("");
          log("Scanner started with rear camera");
        } catch (err) {
          log("Rear camera failed, trying any camera", err);
          try {
            const devices = await Html5Qrcode.getCameras();
            if (devices && devices.length > 0) {
              await html5QrCode.start(devices[0].id, config, onScanSuccess, onScanError);
              setScanning(true);
              setError("");
              log("Scanner started with fallback camera");
            } else {
              throw new Error("No cameras found");
            }
          } catch (fallbackErr) {
            console.error("Camera initialization failed:", fallbackErr);
            setError("Camera access failed. Try manual mode.");
          }
        }
      } catch (err) {
        console.error("Scanner initialization error:", err);
        setError("Scanner initialization failed. Try manual mode.");
      }
    };

    startScanner();

    return () => {
      log("Cleaning up HTML5 QR Code scanner");
      if (html5QrCodeRef.current?.isScanning) {
        html5QrCodeRef.current
          .stop()
          .catch((err) => console.error("Error stopping scanner:", err));
      }
    };
  }, [mode, sendEan, log, verbose, scanQuantity]);

  // ── Style helpers ─────────────────────────────────────────────────────────
  const inputStyle: React.CSSProperties = {
    display: "block",
    width: "100%",
    boxSizing: "border-box",
    padding: "9px 12px",
    backgroundColor: P.bg,
    border: `1px solid ${P.border}`,
    borderRadius: 10,
    color: P.text,
    fontSize: 14,
    outline: "none",
    transition: "border-color 0.15s",
  };

  const qtyBtnStyle = (isPlus: boolean): React.CSSProperties => ({
    all: "unset" as const,
    boxSizing: "border-box" as const,
    width: 44,
    height: 44,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 10,
    fontSize: 22,
    fontWeight: 300,
    cursor: "pointer",
    backgroundColor: isPlus ? P.tealD : P.surface,
    border: `1px solid ${isPlus ? P.tealB : P.border}`,
    color: isPlus ? "#5eead4" : P.muted,
    transition: "all 0.15s",
    flexShrink: 0,
  });

  const submitBtnStyle: React.CSSProperties = {
    all: "unset" as const,
    boxSizing: "border-box" as const,
    display: "block",
    width: "100%",
    textAlign: "center" as const,
    marginTop: 12,
    padding: "10px 0",
    backgroundColor: P.tealD,
    border: `1px solid ${P.tealB}`,
    borderRadius: 10,
    color: "#5eead4",
    fontSize: 14,
    fontWeight: 500,
    cursor: "pointer",
    transition: "all 0.15s",
  };

  const username = localStorage.getItem("username") ?? "L";

  return (
    <div style={{ minHeight: "100vh", backgroundColor: P.bg, paddingBottom: 90 }}>
      {needReauth && (
        <AuthPopup
          onAuthenticated={() => {
            setNeedReauth(false);
            setError("");
          }}
        />
      )}

      <AppHeader username={username} />

      <div className="p-3 sm:p-4 md:p-6">
        <div className="max-w-lg mx-auto">
          {/* Title row */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
            {/* Back */}
            <button
              onClick={async () => {
                await hardStopCamera();
                navHook(-1 as never);
              }}
              style={{
                all: "unset",
                boxSizing: "border-box",
                width: 32,
                height: 32,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: P.surface,
                border: `1px solid ${P.border}`,
                borderRadius: 9,
                color: P.muted,
                cursor: "pointer",
                flexShrink: 0,
                transition: "all 0.15s",
                fontSize: 16,
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color = P.text;
                (e.currentTarget as HTMLElement).style.borderColor = P.tealB;
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color = P.muted;
                (e.currentTarget as HTMLElement).style.borderColor = P.border;
              }}
              aria-label="Back"
            >
              ‹
            </button>

            {/* Headline */}
            <span
              style={{
                flex: 1,
                color: P.text,
                fontSize: 14,
                fontWeight: 600,
                minWidth: 0,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {headline}
              {isWishList && (
                <span style={{ marginLeft: 6, fontSize: 11, color: P.muted, fontWeight: 400 }}>
                  · Wish List
                </span>
              )}
            </span>

            {/* Mode toggle */}
            <div
              style={{
                display: "flex",
                gap: 2,
                backgroundColor: P.surface,
                padding: 3,
                borderRadius: 10,
                border: `1px solid ${P.border}`,
                flexShrink: 0,
              }}
            >
              {(["auto", "manual"] as ScanMode[]).map((m) => (
                <button
                  key={m}
                  onClick={() => setMode(m)}
                  style={{
                    all: "unset",
                    boxSizing: "border-box",
                    padding: "5px 12px",
                    borderRadius: 8,
                    fontSize: 12,
                    fontWeight: 500,
                    cursor: "pointer",
                    transition: "all 0.15s",
                    backgroundColor: mode === m ? P.tealD : "transparent",
                    border: `1px solid ${mode === m ? P.tealB : "transparent"}`,
                    color: mode === m ? "#5eead4" : P.muted,
                  }}
                >
                  {m === "auto" ? "Auto" : "Manual"}
                </button>
              ))}
            </div>

            {/* Verbose toggle */}
            <button
              onClick={() => setVerbose(!verbose)}
              style={{
                all: "unset",
                boxSizing: "border-box",
                width: 32,
                height: 32,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: verbose ? P.tealD : P.surface,
                border: `1px solid ${verbose ? P.tealB : P.border}`,
                borderRadius: 9,
                color: verbose ? "#5eead4" : P.muted,
                cursor: "pointer",
                flexShrink: 0,
                transition: "all 0.15s",
              }}
              title="Toggle verbose logging"
            >
              <svg width="13" height="13" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
                <path d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
            </button>
          </div>

          {/* ── Scan result card ── */}
          {scanResult && (
            <div
              style={{
                backgroundColor: scanResult.known ? P.tealD : P.redD,
                border: `1px solid ${scanResult.known ? P.tealB : P.redB}`,
                borderRadius: 14,
                padding: "14px 16px",
                marginBottom: 12,
                display: "flex",
                alignItems: "flex-start",
                gap: 12,
              }}
            >
              {/* Icon */}
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: "50%",
                  backgroundColor: scanResult.known ? "#0f2a28" : "#3a1010",
                  border: `1px solid ${scanResult.known ? P.tealB : P.redB}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                {scanResult.known ? (
                  <svg width="14" height="14" fill="none" stroke="#5eead4" viewBox="0 0 24 24" strokeWidth="2.5" strokeLinecap="round">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                ) : (
                  <svg width="14" height="14" fill="none" stroke="#f87171" viewBox="0 0 24 24" strokeWidth="2.5" strokeLinecap="round">
                    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                  </svg>
                )}
              </div>

              {/* Details */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: scanResult.known ? "#5eead4" : "#f87171", marginBottom: 4 }}>
                  {scanResult.known
                    ? scanResult.isAdd
                      ? `Added to ${scanResult.isWish ? "Wish List" : "Inventory"}`
                      : `Removed from ${scanResult.isWish ? "Wish List" : "Inventory"}`
                    : "Not recognized"}
                </div>

                {scanResult.itemName && (
                  <div style={{ fontSize: 14, fontWeight: 500, color: P.text, marginBottom: 3 }}>
                    {scanResult.itemName}
                  </div>
                )}

                <div style={{ fontSize: 12, color: P.muted }}>
                  {scanResult.detail}
                </div>

                <div style={{ display: "flex", gap: 12, marginTop: 6 }}>
                  {scanResult.ean && (
                    <span style={{ fontSize: 11, color: P.subtle, fontFamily: "monospace" }}>
                      EAN {scanResult.ean}
                    </span>
                  )}
                  <span style={{ fontSize: 11, color: P.subtle }}>
                    × {scanResult.count}
                  </span>
                </div>
              </div>

              {/* Dismiss */}
              <button
                onClick={() => setScanResult(null)}
                style={{
                  all: "unset",
                  color: P.muted,
                  cursor: "pointer",
                  fontSize: 18,
                  lineHeight: 1,
                  flexShrink: 0,
                  padding: "0 2px",
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.color = P.text)}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.color = P.muted)}
              >
                ×
              </button>
            </div>
          )}

          {mode === "auto" ? (
            /* ── Auto scanner ── */
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {/* Camera card */}
              <div
                style={{
                  backgroundColor: P.surface,
                  border: `1px solid ${P.border}`,
                  borderRadius: 18,
                  padding: 16,
                  boxShadow: "0 8px 32px #00000060",
                }}
              >
                <div
                  id={scannerIdRef.current}
                  style={{
                    borderRadius: 12,
                    overflow: "hidden",
                    border: `2px solid ${P.tealB}`,
                    backgroundColor: "#000",
                    minHeight: 280,
                  }}
                />
                {/* Status */}
                <div style={{ marginTop: 10, textAlign: "center" }}>
                  {showSuccess ? (
                    <span style={{ color: "#5eead4", fontSize: 13, fontWeight: 500 }}>
                      ✓ Added successfully!
                    </span>
                  ) : error ? (
                    <span style={{ color: "#f87171", fontSize: 13 }}>{error}</span>
                  ) : ean ? (
                    <span style={{ color: "#5eead4", fontSize: 13, fontFamily: "monospace" }}>
                      Code: {ean}
                    </span>
                  ) : scanning ? (
                    <span style={{ color: P.muted, fontSize: 13 }}>● Scanning...</span>
                  ) : (
                    <span style={{ color: P.subtle, fontSize: 13 }}>Point at barcode</span>
                  )}
                </div>
                {verbose && (
                  <div
                    style={{
                      marginTop: 10,
                      padding: "7px 10px",
                      backgroundColor: P.bg,
                      borderRadius: 8,
                      border: `1px solid ${P.tealB}`,
                    }}
                  >
                    <p style={{ margin: 0, fontSize: 11, color: P.teal, fontFamily: "monospace" }}>
                      Scans: {scanCount} | Last: {lastScanTime || "N/A"} | Status: {scanning ? "Active" : "Stopped"}
                    </p>
                  </div>
                )}
              </div>

              {/* Scanned code quantity + submit */}
              {scannedCode && (
                <div
                  style={{
                    backgroundColor: P.surface,
                    border: `1px solid ${P.tealB}`,
                    borderRadius: 18,
                    padding: 16,
                  }}
                >
                  <p style={{ margin: "0 0 12px", textAlign: "center", color: "#5eead4", fontSize: 12, fontWeight: 500 }}>
                    Adjust Quantity
                  </p>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, justifyContent: "center" }}>
                    <button type="button" onClick={() => handleQuantityChange(-1, true)} style={qtyBtnStyle(false)}>−</button>
                    <input
                      type="number"
                      value={scanQuantity}
                      onChange={(e) => setScanQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      min="1"
                      style={{
                        width: 80,
                        padding: "10px 8px",
                        backgroundColor: P.bg,
                        border: `2px solid ${P.tealB}`,
                        borderRadius: 10,
                        color: P.text,
                        fontSize: 26,
                        fontWeight: 700,
                        textAlign: "center",
                        outline: "none",
                      }}
                    />
                    <button type="button" onClick={() => handleQuantityChange(1, true)} style={qtyBtnStyle(true)}>+</button>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (scanSubmitTimeoutRef.current) clearTimeout(scanSubmitTimeoutRef.current);
                      sendEan(scannedCode, scanQuantity);
                    }}
                    style={submitBtnStyle}
                  >
                    Submit
                  </button>
                </div>
              )}

              <p style={{ textAlign: "center", color: P.subtle, fontSize: 12 }}>
                Position barcode in the center of the frame
              </p>
            </div>
          ) : (
            /* ── Manual entry ── */
            <div
              style={{
                backgroundColor: P.surface,
                border: `1px solid ${P.border}`,
                borderRadius: 18,
                padding: "20px 16px",
                boxShadow: "0 8px 32px #00000060",
              }}
            >
              {/* Input mode toggle */}
              <div
                style={{
                  display: "flex",
                  gap: 2,
                  backgroundColor: P.bg,
                  padding: 3,
                  borderRadius: 10,
                  border: `1px solid ${P.border}`,
                  marginBottom: 16,
                }}
              >
                {(["name", "ean"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => setInputMode(m)}
                    style={{
                      all: "unset",
                      boxSizing: "border-box",
                      flex: 1,
                      padding: "6px 0",
                      textAlign: "center",
                      borderRadius: 8,
                      fontSize: 12,
                      fontWeight: 500,
                      cursor: "pointer",
                      transition: "all 0.15s",
                      backgroundColor: inputMode === m ? P.tealD : "transparent",
                      border: `1px solid ${inputMode === m ? P.tealB : "transparent"}`,
                      color: inputMode === m ? "#5eead4" : P.muted,
                    }}
                  >
                    {m === "name" ? "By Name" : "By Barcode"}
                  </button>
                ))}
              </div>

              <form onSubmit={handleManualSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {inputMode === "name" ? (
                  <div>
                    <label style={{ display: "block", fontSize: 12, color: P.muted, marginBottom: 6 }}>
                      Item Name
                    </label>
                    <input
                      type="text"
                      value={manualName}
                      onChange={(e) => setManualName(e.target.value)}
                      placeholder="e.g. Milk, Bread, Apples..."
                      autoFocus
                      style={inputStyle}
                      onFocus={(e) => (e.currentTarget.style.borderColor = P.teal)}
                      onBlur={(e) => (e.currentTarget.style.borderColor = P.border)}
                    />
                  </div>
                ) : (
                  <div>
                    <label style={{ display: "block", fontSize: 12, color: P.muted, marginBottom: 6 }}>
                      Barcode (EAN)
                    </label>
                    <input
                      type="text"
                      value={manualEan}
                      onChange={(e) => setManualEan(e.target.value.replace(/\D/g, ""))}
                      placeholder="e.g. 4006040055136"
                      maxLength={14}
                      autoFocus
                      style={{ ...inputStyle, fontFamily: "monospace" }}
                      onFocus={(e) => (e.currentTarget.style.borderColor = P.teal)}
                      onBlur={(e) => (e.currentTarget.style.borderColor = P.border)}
                    />
                    <p style={{ margin: "4px 0 0", fontSize: 11, color: P.subtle, textAlign: "center" }}>
                      {manualEan.length} / 14 digits
                    </p>
                  </div>
                )}

                <div>
                  <label style={{ display: "block", fontSize: 12, color: P.muted, marginBottom: 8 }}>
                    Quantity
                  </label>
                  <div style={{ display: "flex", alignItems: "center", gap: 12, justifyContent: "center" }}>
                    <button type="button" onClick={() => handleQuantityChange(-1)} style={qtyBtnStyle(false)}>−</button>
                    <input
                      type="number"
                      value={manualQuantity}
                      onChange={(e) => setManualQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      min="1"
                      style={{
                        width: 80,
                        padding: "10px 8px",
                        backgroundColor: P.bg,
                        border: `2px solid ${P.tealB}`,
                        borderRadius: 10,
                        color: P.text,
                        fontSize: 26,
                        fontWeight: 700,
                        textAlign: "center",
                        outline: "none",
                      }}
                    />
                    <button type="button" onClick={() => handleQuantityChange(1)} style={qtyBtnStyle(true)}>+</button>
                  </div>
                </div>

                {error && (
                  <div style={{ padding: "8px 12px", backgroundColor: P.redD, border: `1px solid ${P.redB}`, borderRadius: 10, fontSize: 13, color: "#f87171" }}>
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={
                    (inputMode === "ean" && (!manualEan || manualEan.length < 8)) ||
                    (inputMode === "name" && !manualName.trim()) ||
                    showSuccess
                  }
                  style={{
                    ...submitBtnStyle,
                    opacity:
                      (inputMode === "ean" && (!manualEan || manualEan.length < 8)) ||
                      (inputMode === "name" && !manualName.trim()) ||
                      showSuccess
                        ? 0.4
                        : 1,
                    cursor:
                      (inputMode === "ean" && (!manualEan || manualEan.length < 8)) ||
                      (inputMode === "name" && !manualName.trim()) ||
                      showSuccess
                        ? "not-allowed"
                        : "pointer",
                  }}
                >
                  Add to {isWishList ? "Wish List" : "Grocery List"}
                </button>
              </form>

              {verbose && (
                <div style={{ marginTop: 12, padding: "7px 10px", backgroundColor: P.bg, borderRadius: 8, border: `1px solid ${P.tealB}` }}>
                  <p style={{ margin: 0, fontSize: 11, color: P.teal, fontFamily: "monospace" }}>
                    Mode: {inputMode} | Quantity: {manualQuantity}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Quantity modal ── */}
      {pendingQuantity && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.75)", zIndex: 300, display: "flex", alignItems: "flex-end", backdropFilter: "blur(4px)" }}
          onClick={() => setPendingQuantity(null)}
        >
          <div
            style={{ background: P.surface, borderRadius: "24px 24px 0 0", padding: "20px 20px 48px", width: "100%", maxWidth: 480, margin: "0 auto" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Handle */}
            <div style={{ width: 36, height: 4, borderRadius: 2, background: P.border, margin: "0 auto 18px" }} />

            {/* Header */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <svg width="16" height="16" fill="none" stroke="#5eead4" viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round">
                <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <span style={{ fontSize: 15, fontWeight: 700, color: P.text }}>Packungsinhalt unbekannt</span>
            </div>
            <p style={{ margin: "0 0 18px", fontSize: 13, color: P.muted }}>
              Wie viel enthält eine Packung „{pendingQuantity.itemName}"? Deine Angabe hilft dir beim Wochenplaner.
            </p>

            {/* Amount + unit row */}
            <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
              <div style={{ flex: 1 }}>
                <label style={{ display: "block", fontSize: 11, color: P.muted, marginBottom: 5 }}>Menge</label>
                <input
                  type="number"
                  min="0.1"
                  step="any"
                  value={qtyAmount}
                  onChange={(e) => setQtyAmount(e.target.value)}
                  style={{ width: "100%", boxSizing: "border-box", padding: "10px 12px", background: P.bg, border: `1px solid ${P.tealB}`, borderRadius: 10, color: P.text, fontSize: 16, fontWeight: 700, outline: "none" }}
                />
              </div>
              <div style={{ width: 110 }}>
                <label style={{ display: "block", fontSize: 11, color: P.muted, marginBottom: 5 }}>Einheit</label>
                <select
                  value={qtyUnit}
                  onChange={(e) => setQtyUnit(e.target.value)}
                  style={{ width: "100%", boxSizing: "border-box", padding: "10px 12px", background: P.bg, border: `1px solid ${P.border}`, borderRadius: 10, color: P.text, fontSize: 14, outline: "none", cursor: "pointer" }}
                >
                  {QUANTITY_UNITS.map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Actions */}
            <button
              onClick={() => void saveVerifiedProduct()}
              disabled={qtySaving || !qtyAmount || parseFloat(qtyAmount) <= 0}
              style={{ width: "100%", padding: 13, borderRadius: 13, background: "#0d9488", color: "#fff", fontSize: 14, fontWeight: 800, border: "none", cursor: "pointer", marginBottom: 10, fontFamily: "inherit", opacity: qtySaving ? 0.6 : 1, transition: "opacity 0.15s" }}
            >
              {qtySaving ? "Wird gespeichert…" : "Speichern"}
            </button>
            <button
              onClick={() => setPendingQuantity(null)}
              style={{ width: "100%", padding: 12, borderRadius: 13, background: P.surface, color: P.muted, fontSize: 13, fontWeight: 700, border: `1px solid ${P.border}`, cursor: "pointer", fontFamily: "inherit" }}
            >
              Überspringen
            </button>
          </div>
        </div>
      )}

      <BottomTabBar />
    </div>
  );
}
