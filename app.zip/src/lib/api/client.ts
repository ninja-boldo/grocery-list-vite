import { authApiCall, type AuthApiCallConfig } from "@/lib/authApi";
import {
  API_PATHS,
  buildClassifyItemsAgainstPantryUrl,
  buildFetchItemsUrl,
  buildGetCatalogueOffersUrl,
  buildGetSupermarketsCloseUrl,
  type AddEanRequest,
  type AddEanToListResponse,
  type AddRecipePayload,
  type AddWeekPlanPayload,
  type ChangePasswordRequest,
  type ClassifyItemsResponse,
  type FetchItemsQuery,
  type GetCatalogueOffersQuery,
  type GetSupermarketsCloseQuery,
  type MealSlotPayload,
  type PantryClassificationWishItem,
  type PlannerSettingsPayload,
  type TokenResponse,
} from "@/lib/api/openapi";

export type GenericApiResponse = {
  status?: string;
  message?: string;
  detail?: string;
  code?: number;
  [key: string]: unknown;
};

export type FetchItemsResponse = {
  items: Array<{
    ean: string;
    text: string | null;
    shortened_name?: string | null;
    count: number;
    perish_dates: string[];
    imageUrl: string;
    tags: string | null;
    mapped_items?: Array<{ count: number; item_name: string }>;
  }>;
  accumulated_count?: number;
  distinct_items?: number;
};

export type AddSupermarketPayload = {
  name?: string | null;
  address?: string | null;
  city?: string | null;
  category?: string | null;
  postcode?: number | null;
  latitude?: number | null;
  longitude?: number | null;
};

export type AddFetchedItemPayload = {
  userId: string;
  ean: string;
  item_name?: string | null;
  per_date_count: number[];
  perish_dates: string[];
  isWished: string;
};

export type AddFetchedItemsPayload = {
  items: AddFetchedItemPayload[];
};

export type RecipeIngredient = {
  amount: number | null;
  unit: string | null;
  name: string;
  count: number | null;
};

export type RecipeItem = {
  recipe_id: number;
  name: string | null;
  base_time: number;
  default_portions: number;
  tags: string[];
  emoji: string | null;
  ingredients: RecipeIngredient[];
  steps: string[];
};

export type RecipesResponse = {
  recipes: RecipeItem[];
  recipe_count: number;
};

export type WeekPlanResponse = {
  week_plan: string;
  week_settings: unknown;
  code: number;
};

export type PlannerSettingsResponse = {
  planner_settings: PlannerSettingsPayload;
  status: string;
  message: string;
  code: number;
};

export type HealthResponse = {
  status: string;
  timestamp: string;
  database?: string;
  whisper?: string;
  ml_model?: string;
};

const JSON_HEADERS = {
  "Content-Type": "application/json; charset=UTF-8",
};

const toFormBody = (payload: {
  username: string;
  password: string;
  scope?: string;
  client_id?: string;
  client_secret?: string;
  grant_type?: string;
}) => {
  const form = new URLSearchParams();
  form.set("username", payload.username);
  form.set("password", payload.password);
  form.set("scope", payload.scope ?? "");
  if (payload.client_id) {
    form.set("client_id", payload.client_id);
  }
  if (payload.client_secret) {
    form.set("client_secret", payload.client_secret);
  }
  if (payload.grant_type) {
    form.set("grant_type", payload.grant_type);
  }
  return form.toString();
};

async function unauthenticatedApiCall<T>(
  url: string,
  options: RequestInit = {},
): Promise<T> {
  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    return (await response.json()) as T;
  }
  return (await response.text()) as T;
}

export const apiClient = {
  metrics: async (): Promise<unknown> => {
    return unauthenticatedApiCall<unknown>(API_PATHS.metrics);
  },

  loginForAccessToken: async (payload: {
    username: string;
    password: string;
    scope?: string;
    client_id?: string;
    client_secret?: string;
    grant_type?: string;
  }): Promise<TokenResponse> => {
    return unauthenticatedApiCall<TokenResponse>(API_PATHS.token, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: toFormBody(payload),
    });
  },

  changePassword: async (
    payload: ChangePasswordRequest,
    config?: AuthApiCallConfig,
  ): Promise<{ done: boolean }> => {
    return authApiCall<{ done: boolean }>(
      API_PATHS.changePassword,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  fetchItems: async (
    query: FetchItemsQuery = {},
    config?: AuthApiCallConfig,
  ): Promise<FetchItemsResponse> => {
    return authApiCall<FetchItemsResponse>(buildFetchItemsUrl(query), undefined, config);
  },

  getCatalogueOffers: async (
    query: GetCatalogueOffersQuery,
    config?: AuthApiCallConfig,
  ): Promise<unknown> => {
    return authApiCall<unknown>(buildGetCatalogueOffersUrl(query), undefined, config);
  },

  addNewMarket: async (
    payload: AddSupermarketPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.addNewMarket,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  postCatalogue: async (
    payload: FormData,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.postCatalogue,
      {
        method: "POST",
        body: payload,
      },
      config,
    );
  },

  getSupermarketsClose: async (
    query: GetSupermarketsCloseQuery,
    config?: AuthApiCallConfig,
  ): Promise<unknown> => {
    return authApiCall<unknown>(buildGetSupermarketsCloseUrl(query), undefined, config);
  },

  getRecipes: async (config?: AuthApiCallConfig): Promise<RecipesResponse> => {
    return authApiCall<RecipesResponse>(API_PATHS.recipes, undefined, config);
  },

  addRecipe: async (
    payload: AddRecipePayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.recipes,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  addFetchedItems: async (
    payload: AddFetchedItemsPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.addFetchedItems,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  deleteRecipe: async (
    recipeId: number,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.recipeById(recipeId),
      {
        method: "DELETE",
      },
      config,
    );
  },

  getRecipeById: async (
    recipeId: number,
    config?: AuthApiCallConfig,
  ): Promise<RecipeItem | GenericApiResponse> => {
    return authApiCall<RecipeItem | GenericApiResponse>(
      API_PATHS.recipeById(recipeId),
      undefined,
      config,
    );
  },

  getWeekPlan: async (config?: AuthApiCallConfig): Promise<WeekPlanResponse> => {
    return authApiCall<WeekPlanResponse>(API_PATHS.weekPlan, undefined, config);
  },

  postWeekPlan: async (
    payload: AddWeekPlanPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.weekPlan,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  deleteMealSlot: async (
    payload: MealSlotPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.weekPlan,
      {
        method: "DELETE",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  getPlannerSettings: async (
    config?: AuthApiCallConfig,
  ): Promise<PlannerSettingsResponse> => {
    return authApiCall<PlannerSettingsResponse>(
      API_PATHS.plannerSettings,
      undefined,
      config,
    );
  },

  putPlannerSettings: async (
    payload: PlannerSettingsPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.plannerSettings,
      {
        method: "PUT",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  classifyItemsAgainstPantry: async (
    itemsWished: PantryClassificationWishItem[],
    config?: AuthApiCallConfig & { autoAddItems?: boolean },
  ): Promise<ClassifyItemsResponse> => {
    return authApiCall<ClassifyItemsResponse>(
      buildClassifyItemsAgainstPantryUrl(itemsWished, config?.autoAddItems),
      undefined,
      config,
    );
  },

  replaceMeal: async (
    payload: MealSlotPayload,
    config?: AuthApiCallConfig,
  ): Promise<GenericApiResponse> => {
    return authApiCall<GenericApiResponse>(
      API_PATHS.replaceMeal,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  addEanToList: async (
    payload: AddEanRequest,
    config?: AuthApiCallConfig,
  ): Promise<AddEanToListResponse> => {
    return authApiCall<AddEanToListResponse>(
      API_PATHS.addEanToList,
      {
        method: "POST",
        headers: JSON_HEADERS,
        body: JSON.stringify(payload),
      },
      config,
    );
  },

  health: async (): Promise<HealthResponse> => {
    return unauthenticatedApiCall<HealthResponse>(API_PATHS.health);
  },
};
