import i18next from 'i18next'
export const API_PATHS = {
  token: "/api/token",
  changePassword: "/api/change_password",
  fetchItems: "/api/fetch_items",
  getCatalogueOffers: "/api/get_catalogue_offers",
  addNewMarket: "/api/add_new_market",
  postCatalogue: "/api/post_catalogue",
  getSupermarketsClose: "/api/get_supermarkets_close",
  recipes: "/api/recipes",
  addFetchedItems: "/api/add_fetched_items",
  recipeById: (id: number) => `/api/recipes/${id}`,
  weekPlan: "/api/week_plan",
  replaceMeal: "/api/week_plan/replace_meal",
  plannerSettings: "/api/planner_settings",
  classifyItemsAgainstPantry: "/api/classify_items_against_pantry",
  addEanToList: "/api/add_ean_to_list/",
  health: "/api/health",
  metrics: "/api/metrics",
} as const;

type Nullable<T> = T | null | undefined;

export type FetchItemsQuery = {
  onlyWishList?: boolean;
  sortOrder?: Nullable<string>;
  skip?: Nullable<number>;
  limit?: Nullable<number>;
  searchQuery?: Nullable<string>;
  userId?: Nullable<string | number>;
};

export type GetSupermarketsCloseQuery = {
  lat: number;
  lon: number;
  radiusMeters?: number;
  chains?: string[];
};

export type GetCatalogueOffersQuery = {
  longitude: number;
  latitude: number;
  deprecationDays?: number;
};

export type PantryClassificationWishItem = {
  item_name: string;
  item_id: string;
  count: number;
  quantity: {
    product_quantity: number | null;
    product_quantity_unit: string | null;
  };
  info?: string;
};

export type PantryClassificationMapping = {
  pantryItem: {
    item_name: string;
    item_id: string;
    count: number;
    quantity: { product_quantity: number | null; product_quantity_unit: string | null };
  };
  mappedWishItem: {
    item_name: string;
    item_id: string;
    count: number;
    quantity: { product_quantity: number | null; product_quantity_unit: string | null };
  } | null;
  foundMappingWish: boolean;
};

export type ClassifyItemsResponse = {
  message: string;
  status: string;
  mapping: PantryClassificationMapping[];
};

export type AddEanToListResponse = {
  ean: string | null;
  product_name: string | null;
  done: boolean;
  known_to_db: boolean | string;
  mode: string;
  operation: string;
  state?: string;
  status?: string;
  message?: string;
  detail?: string;
  error?: string;
  suggestion?: string;
  item_name?: string | null;
  quantity_needed?: boolean;
};

const setIfPresent = (
  params: URLSearchParams,
  key: string,
  value: Nullable<string | number>,
) => {
  if (value === null || value === undefined) {
    return;
  }
  const normalized = String(value).trim();
  if (!normalized) {
    return;
  }
  params.set(key, normalized);
};

const withQuery = (basePath: string, params: URLSearchParams): string => {
  const query = params.toString();
  if (!query) {
    return basePath;
  }
  return `${basePath}?${query}`;
};

export const buildFetchItemsUrl = (query: FetchItemsQuery = {}): string => {
  const params = new URLSearchParams();
  if (typeof query.onlyWishList === "boolean") {
    params.set("only_wish_list", String(query.onlyWishList));
  }
  setIfPresent(params, "sortOrder", query.sortOrder);
  setIfPresent(params, "skip", query.skip);
  setIfPresent(params, "limit", query.limit);
  setIfPresent(params, "searchQuery", query.searchQuery);
  setIfPresent(params, "userId", query.userId);
  return withQuery(API_PATHS.fetchItems, params);
};

export const buildGetSupermarketsCloseUrl = (
  query: GetSupermarketsCloseQuery,
): string => {
  const params = new URLSearchParams();
  params.set("lat", String(query.lat));
  params.set("lon", String(query.lon));
  params.set("radius_meters", String(query.radiusMeters ?? 2000));
  if (Array.isArray(query.chains)) {
    query.chains
      .map((chain) => chain.trim())
      .filter(Boolean)
      .forEach((chain) => params.append("chains", chain));
  }
  return withQuery(API_PATHS.getSupermarketsClose, params);
};

export const buildGetCatalogueOffersUrl = (
  query: GetCatalogueOffersQuery,
): string => {
  const params = new URLSearchParams();
  params.set("longitude", String(query.longitude));
  params.set("latitude", String(query.latitude));
  params.set("DeprecationDays", String(query.deprecationDays ?? 30));
  return withQuery(API_PATHS.getCatalogueOffers, params);
};

export const buildClassifyItemsAgainstPantryUrl = (
  itemsWished: PantryClassificationWishItem[],
  autoAddItems?: boolean,
): string => {
  const params = new URLSearchParams();
  params.set("itemsWished", JSON.stringify(itemsWished));
  if (autoAddItems !== undefined) {
    params.set("autoAddItems", String(autoAddItems));
  }
  return withQuery(API_PATHS.classifyItemsAgainstPantry, params);
};

export type TokenResponse = {
  access_token: string;
  token_type: string;
};

export type ChangePasswordRequest = {
  current_password: string;
  new_password: string;
};

export type QuantityInfo = {
  product_quantity: number | null;
  product_quantity_unit: string | null;
};

export type AddEanRequest = {
  ean?: string | null;
  item_name?: string | null;
  count?: number | null;
  wish_list?: string | null;
  quantity_data?: QuantityInfo | null;
};

export type IngredientPayload = {
  amount: number | null;
  unit: string | null;
  name: string;
  count?: number | null;
};

export type AddRecipePayload = {
  name: string;
  emoji: string;
  baseTime: number;
  baseServings?: number | null;
  tags?: string[] | null;
  favorited?: boolean | null;
  ingredients: IngredientPayload[];
  steps: string[];
};

export type MealSlotPayload = {
  recipe_id: number;
  servings: number;
  meal_type: string;
  day: string;
  day_time: string;
};

export type DayPlanPayload = {
  breakfast: MealSlotPayload | null;
  lunch: MealSlotPayload | null;
  dinner: MealSlotPayload | null;
};

export type DaySettingsPayload = {
  day: string;
  day_meal_time_type?: string;
  breakfast_blocked?: boolean;
  lunch_blocked?: boolean;
  dinner_blocked?: boolean;
};

export type WeekPlanPayload = {
  mo?: DayPlanPayload;
  tu?: DayPlanPayload;
  we?: DayPlanPayload;
  th?: DayPlanPayload;
  fr?: DayPlanPayload;
  sa?: DayPlanPayload;
  su?: DayPlanPayload;
};

export type WeekSettingsPayload = {
  mo?: DaySettingsPayload;
  tu?: DaySettingsPayload;
  we?: DaySettingsPayload;
  th?: DaySettingsPayload;
  fr?: DaySettingsPayload;
  sa?: DaySettingsPayload;
  su?: DaySettingsPayload;
};

export type AddWeekPlanPayload = {
  week: WeekPlanPayload;
  DaySettings: WeekSettingsPayload;
};

export type PlannerSettingsPayload = {
  defaultServings: number;
  quickMealMinutes: number;
  normalMealMinutes: number;
};


/** Enum matching backend DayType */
export type DayType = "quick" | "normal" | "relaxed";

/** Single item for the add_fetched_items endpoint */
export type FetchedSingleItem = {
  userId: string;
  ean: string;
  item_name?: string | null;
  per_date_count: number[];
  perish_dates: string[];
  isWished: string;
};

/** Body for POST /add_fetched_items */
export type AddFetchedItemsRequest = {
  items: FetchedSingleItem[];
};

/** Body for POST /add_new_market */
export type AddSupermarketRequest = {
  name?: string | null;
  address?: string | null;
  city?: string | null;
  category?: string | null;
  postcode?: number | null;
  latitude?: number | null;
  longitude?: number | null;
};

/**
 * Single ingredient as returned / accepted by the backend.
 * Alias: IngredientPayload (kept for compatibility).
 */
export type Ingredient = {
  amount?: number | null;
  unit?: string | null;
  name: string;
  count?: number | null;
};

/** Full recipe payload as accepted by POST /recipes. Alias: AddRecipePayload */
export type AddRecipe = {
  name: string;
  emoji: string;
  baseTime: number;
  baseServings?: number | null;
  tags?: string[] | null;
  favorited?: boolean | null;
  ingredients: Ingredient[];
  steps: string[];
};

/** Meal slot as accepted/returned by the backend week-plan endpoints. */
export type MealSlot = {
  recipe_id: number;
  servings: number;
  meal_type: string;
  day: string;
  day_time: string;
};

/** Day-level plan (breakfast / lunch / dinner slots). */
export type DayPlan = {
  breakfast?: MealSlot | null;
  lunch?: MealSlot | null;
  dinner?: MealSlot | null;
};

/** Day-specific planner settings. */
export type DaySettings = {
  day: string;
  day_meal_time_type?: DayType;
  breakfast_blocked?: boolean;
  lunch_blocked?: boolean;
  dinner_blocked?: boolean;
};

/** Full week plan (keyed by two-letter day abbreviation). */
export type WeekPlan = {
  mo?: DayPlan;
  tu?: DayPlan;
  we?: DayPlan;
  th?: DayPlan;
  fr?: DayPlan;
  sa?: DayPlan;
  su?: DayPlan;
};

/** Full week settings (keyed by two-letter day abbreviation). */
export type WeekSettings = {
  mo?: DaySettings;
  tu?: DaySettings;
  we?: DaySettings;
  th?: DaySettings;
  fr?: DaySettings;
  sa?: DaySettings;
  su?: DaySettings;
};

/** Body for POST /week_plan. */
export type AddWeekPlan = {
  week: WeekPlan;
  DaySettings: WeekSettings;
};

/** Standard FastAPI validation error detail entry. */
export type ValidationError = {
  loc: (string | number)[];
  msg: string;
  type: string;
  input?: unknown;
  ctx?: Record<string, unknown>;
};

/** Standard FastAPI 422 response body. */
export type HTTPValidationError = {
  detail?: ValidationError[];
};