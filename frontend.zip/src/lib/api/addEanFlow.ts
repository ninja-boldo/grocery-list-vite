import type { AddEanToListResponse } from "@/lib/api/openapi";

const QUANTITY_HINT_PATTERN =
  /\b(quantity|quantit|menge|packung|unit|manual quantity)\b/i;

const normalizeString = (value: unknown): string =>
  typeof value === "string" ? value.trim().toLowerCase() : "";

const isTrueLike = (value: unknown): boolean => {
  if (typeof value === "boolean") {
    return value;
  }
  const normalized = normalizeString(value);
  return normalized === "true" || normalized === "yes" || normalized === "ok";
};

const hasQuantityHint = (...values: unknown[]): boolean => {
  const text = values
    .filter((value): value is string => typeof value === "string")
    .join(" ")
    .trim();

  return Boolean(text) && QUANTITY_HINT_PATTERN.test(text);
};

export const needsQuantityDetails = (
  response: Partial<AddEanToListResponse> | null | undefined,
): boolean => {
  if (!response) {
    return false;
  }

  if (response.quantity_needed === true) {
    return true;
  }

  const state = normalizeString(response.state);
  const status = normalizeString(response.status);
  const looksLikeError = state === "error" || status === "error";

  if (
    looksLikeError &&
    hasQuantityHint(response.detail, response.error, response.suggestion, response.message)
  ) {
    return true;
  }

  return hasQuantityHint(response.suggestion) && isTrueLike(response.known_to_db) === false;
};

export const isAddEanSuccess = (
  response: Partial<AddEanToListResponse> | null | undefined,
): boolean => {
  if (!response || needsQuantityDetails(response)) {
    return false;
  }

  if (response.done === true) {
    return true;
  }

  const state = normalizeString(response.state);
  if (state === "success") {
    return true;
  }

  const status = normalizeString(response.status);
  if (status === "success" || status === "ok") {
    return true;
  }

  if (isTrueLike(response.known_to_db)) {
    const detail = normalizeString(response.detail);
    return detail !== "failed to add item";
  }

  return false;
};
