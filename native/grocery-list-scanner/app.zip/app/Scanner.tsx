/**
 * Scanner.tsx — Native barcode scanner screen
 *
 * Navigated to when the WebView intercepts /scanner (with optional query params).
 * URL params forwarded via navigation.navigate("scanner", { wishList, count, text })
 *
 * Modes:
 *   Auto   → live camera barcode scan (EAN-8/13)
 *   Manual → "By Name" text input  |  "By Barcode" numeric input
 *
 * After a successful scan/submit, if the API responds with
 * mode === "needs_quantity" (or needs_quantity === true), a bottom-sheet
 * modal prompts for product_quantity + product_quantity_unit, then re-submits
 * with quantity_data populated.
 *
 * Theme: reads localStorage "theme" ("dark"|"light") via the WebView bridge,
 * then falls back to Appearance.getColorScheme().
 *
 * i18n: reads localStorage "i18n_lang" (en|de|pt|fr|es|tr) via bridge.
 */

import { CameraView, useCameraPermissions } from "expo-camera";
import * as Haptics from "expo-haptics";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  Animated,
  Appearance,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableWithoutFeedback,
  View,
} from "react-native";
import { useNavigation, useRoute } from "@react-navigation/native";
import { useAuthSession } from "../lib/AuthSession";
import { MOBILE_LOGIN_ROUTE } from "../lib/config";
import { addEanToList } from "../lib/api";

// ─── Types ────────────────────────────────────────────────────────────────────

type ScannerMode = "auto" | "manual";
type ManualTab = "name" | "barcode";
type InventoryAction = "add" | "remove";
type ColorScheme = "dark" | "light";

interface QuantityInfo {
  product_quantity: number | null;
  product_quantity_unit: string | null;
}

interface ApiResponse {
  ean?: string | null;
  product_name?: string | null;
  done?: boolean;
  known_to_db?: boolean | string;
  mode?: string;
  operation?: string;
  needs_quantity?: boolean;
}

// ─── i18n ─────────────────────────────────────────────────────────────────────

type LangKey =
  | "back" | "title" | "auto" | "manual" | "byName" | "byBarcode"
  | "itemName" | "namePlaceholder" | "barcodeLabel" | "barcodePlaceholder"
  | "units" | "addBtn" | "removeBtn" | "pointCamera" | "noCameraTitle"
  | "noCameraBody" | "allowCamera" | "added" | "removed" | "networkError"
  | "sessionMissing" | "abort" | "working" | "wishlist" | "inventory"
  | "digits" | "quantityModalTitle" | "quantityModalSubtitle" | "quantityModalSave"
  | "quantityModalCancel" | "quantityLabel" | "unitLabel" | "quantityRequired";

const I18N: Record<string, Record<LangKey, string>> = {
  en: {
    back: "← Back",
    title: "Add / Remove",
    auto: "Auto",
    manual: "Manual",
    byName: "By Name",
    byBarcode: "By Barcode",
    itemName: "Item name",
    namePlaceholder: "e.g. Milk, Bread, Apples…",
    barcodeLabel: "Barcode / EAN",
    barcodePlaceholder: "e.g. 4006040055136",
    units: "Units",
    addBtn: "Add",
    removeBtn: "Remove",
    pointCamera: "Point camera at barcode",
    noCameraTitle: "Camera Access",
    noCameraBody: "Allow camera access to scan barcodes",
    allowCamera: "Allow Camera",
    added: "Added",
    removed: "Removed",
    networkError: "Network error",
    sessionMissing: "Session missing — please sign in",
    abort: "Cancel scan",
    working: "Working…",
    wishlist: "Wish list",
    inventory: "Inventory",
    digits: "digits",
    quantityModalTitle: "Add Quantity & Unit",
    quantityModalSubtitle: "The server needs quantity info for",
    quantityModalSave: "Save item with quantity",
    quantityModalCancel: "Cancel",
    quantityLabel: "QUANTITY",
    unitLabel: "UNIT",
    quantityRequired: "QUANTITY REQUIRED",
  },
  de: {
    back: "← Zurück",
    title: "Hinzufügen / Löschen",
    auto: "Auto",
    manual: "Manuell",
    byName: "Nach Name",
    byBarcode: "Nach Barcode",
    itemName: "Artikelname",
    namePlaceholder: "z.B. Milch, Brot, Äpfel…",
    barcodeLabel: "Barcode / EAN",
    barcodePlaceholder: "z.B. 4006040055136",
    units: "Einheiten",
    addBtn: "Hinzufügen",
    removeBtn: "Löschen",
    pointCamera: "Kamera auf Barcode richten",
    noCameraTitle: "Kamerazugriff",
    noCameraBody: "Kamerazugriff erlauben, um Barcodes zu scannen",
    allowCamera: "Kamera erlauben",
    added: "Hinzugefügt",
    removed: "Entfernt",
    networkError: "Netzwerkfehler",
    sessionMissing: "Sitzung fehlt – bitte anmelden",
    abort: "Scan abbrechen",
    working: "Wird verarbeitet…",
    wishlist: "Einkaufsliste",
    inventory: "Inventar",
    digits: "Ziffern",
    quantityModalTitle: "Menge und Einheit hinzufügen",
    quantityModalSubtitle: "Der Server benötigt Mengenangaben für",
    quantityModalSave: "Artikel mit Menge speichern",
    quantityModalCancel: "Abbrechen",
    quantityLabel: "EINHEITEN",
    unitLabel: "EINHEIT",
    quantityRequired: "MENGE ERFORDERLICH",
  },
  pt: {
    back: "← Voltar",
    title: "Adicionar / Remover",
    auto: "Auto",
    manual: "Manual",
    byName: "Por Nome",
    byBarcode: "Por Código",
    itemName: "Nome do item",
    namePlaceholder: "ex: Leite, Pão, Maçãs…",
    barcodeLabel: "Código de barras / EAN",
    barcodePlaceholder: "ex: 4006040055136",
    units: "Unidades",
    addBtn: "Adicionar",
    removeBtn: "Remover",
    pointCamera: "Aponte a câmera para o código",
    noCameraTitle: "Acesso à câmera",
    noCameraBody: "Permita o acesso à câmera para escanear códigos",
    allowCamera: "Permitir câmera",
    added: "Adicionado",
    removed: "Removido",
    networkError: "Erro de rede",
    sessionMissing: "Sessão expirada — faça login",
    abort: "Cancelar scan",
    working: "Processando…",
    wishlist: "Lista de compras",
    inventory: "Inventário",
    digits: "dígitos",
    quantityModalTitle: "Adicionar Quantidade e Unidade",
    quantityModalSubtitle: "O servidor precisa de informações de quantidade para",
    quantityModalSave: "Salvar item com quantidade",
    quantityModalCancel: "Cancelar",
    quantityLabel: "QUANTIDADE",
    unitLabel: "UNIDADE",
    quantityRequired: "QUANTIDADE NECESSÁRIA",
  },
  fr: {
    back: "← Retour",
    title: "Ajouter / Supprimer",
    auto: "Auto",
    manual: "Manuel",
    byName: "Par Nom",
    byBarcode: "Par Code",
    itemName: "Nom de l'article",
    namePlaceholder: "ex : Lait, Pain, Pommes…",
    barcodeLabel: "Code-barres / EAN",
    barcodePlaceholder: "ex : 4006040055136",
    units: "Unités",
    addBtn: "Ajouter",
    removeBtn: "Supprimer",
    pointCamera: "Pointez la caméra vers le code",
    noCameraTitle: "Accès caméra",
    noCameraBody: "Autoriser l'accès caméra pour scanner les codes",
    allowCamera: "Autoriser la caméra",
    added: "Ajouté",
    removed: "Supprimé",
    networkError: "Erreur réseau",
    sessionMissing: "Session manquante — veuillez vous connecter",
    abort: "Annuler le scan",
    working: "En cours…",
    wishlist: "Liste de courses",
    inventory: "Inventaire",
    digits: "chiffres",
    quantityModalTitle: "Ajouter Quantité et Unité",
    quantityModalSubtitle: "Le serveur a besoin d'informations de quantité pour",
    quantityModalSave: "Enregistrer l'article avec la quantité",
    quantityModalCancel: "Annuler",
    quantityLabel: "QUANTITÉ",
    unitLabel: "UNITÉ",
    quantityRequired: "QUANTITÉ REQUISE",
  },
  es: {
    back: "← Atrás",
    title: "Añadir / Eliminar",
    auto: "Auto",
    manual: "Manual",
    byName: "Por Nombre",
    byBarcode: "Por Código",
    itemName: "Nombre del artículo",
    namePlaceholder: "ej: Leche, Pan, Manzanas…",
    barcodeLabel: "Código de barras / EAN",
    barcodePlaceholder: "ej: 4006040055136",
    units: "Unidades",
    addBtn: "Añadir",
    removeBtn: "Eliminar",
    pointCamera: "Apunte la cámara al código",
    noCameraTitle: "Acceso a la cámara",
    noCameraBody: "Permita el acceso a la cámara para escanear códigos",
    allowCamera: "Permitir cámara",
    added: "Añadido",
    removed: "Eliminado",
    networkError: "Error de red",
    sessionMissing: "Sesión no encontrada — inicie sesión",
    abort: "Cancelar escaneo",
    working: "Procesando…",
    wishlist: "Lista de la compra",
    inventory: "Inventario",
    digits: "dígitos",
    quantityModalTitle: "Añadir Cantidad y Unidad",
    quantityModalSubtitle: "El servidor necesita información de cantidad para",
    quantityModalSave: "Guardar artículo con cantidad",
    quantityModalCancel: "Cancelar",
    quantityLabel: "CANTIDAD",
    unitLabel: "UNIDAD",
    quantityRequired: "CANTIDAD REQUERIDA",
  },
  tr: {
    back: "← Geri",
    title: "Ekle / Çıkar",
    auto: "Otomatik",
    manual: "Manuel",
    byName: "İsme Göre",
    byBarcode: "Barkoda Göre",
    itemName: "Ürün adı",
    namePlaceholder: "örn: Süt, Ekmek, Elma…",
    barcodeLabel: "Barkod / EAN",
    barcodePlaceholder: "örn: 4006040055136",
    units: "Birim",
    addBtn: "Ekle",
    removeBtn: "Çıkar",
    pointCamera: "Kamerayı barkoda tutun",
    noCameraTitle: "Kamera Erişimi",
    noCameraBody: "Barkod taramak için kamera erişimine izin verin",
    allowCamera: "Kameraya İzin Ver",
    added: "Eklendi",
    removed: "Çıkarıldı",
    networkError: "Ağ hatası",
    sessionMissing: "Oturum bulunamadı — lütfen giriş yapın",
    abort: "Taramayı iptal et",
    working: "İşleniyor…",
    wishlist: "Alışveriş listesi",
    inventory: "Envanter",
    digits: "basamak",
    quantityModalTitle: "Miktar ve Birim Ekle",
    quantityModalSubtitle: "Sunucu şu ürün için miktar bilgisi gerektiriyor:",
    quantityModalSave: "Ürünü miktarla kaydet",
    quantityModalCancel: "İptal",
    quantityLabel: "MİKTAR",
    unitLabel: "BİRİM",
    quantityRequired: "MİKTAR GEREKLİ",
  },
};

const UNIT_OPTIONS = ["Stück", "g", "kg", "ml", "l", "Packung", "Dose", "Flasche", "Beutel"];

// ─── Theme tokens ─────────────────────────────────────────────────────────────

const DARK = {
  bg: "#0d0f14",
  surface: "#161b25",
  surfaceAlt: "#1e2535",
  border: "rgba(255,255,255,0.08)",
  borderFocus: "#6366f1",
  text: "#f1f5f9",
  textSub: "rgba(255,255,255,0.45)",
  textMuted: "rgba(255,255,255,0.3)",
  accent: "#6366f1",
  accentBg: "rgba(99,102,241,0.15)",
  success: "#16a34a",
  successBg: "#052e16",
  successText: "#4ade80",
  danger: "#dc2626",
  dangerBg: "#450a0a",
  dangerText: "#fca5a5",
  dangerBorder: "#7f1d1d",
  pill: "rgba(255,255,255,0.06)",
  pillActive: "#6366f1",
  segBg: "rgba(255,255,255,0.05)",
  toastSuccessBg: "#052e16",
  toastSuccessText: "#4ade80",
  toastErrorBg: "#450a0a",
  toastErrorText: "#fca5a5",
  modalBg: "#161b25",
  scanOverlay: "rgba(13,15,20,0.55)",
  corner: "rgba(99,102,241,0.8)",
  glass: "rgba(13,15,20,0.82)",
};

const LIGHT = {
  bg: "#f4f4f0",
  surface: "#ffffff",
  surfaceAlt: "#f8f8f5",
  border: "rgba(0,0,0,0.08)",
  borderFocus: "#6366f1",
  text: "#111827",
  textSub: "rgba(0,0,0,0.5)",
  textMuted: "rgba(0,0,0,0.3)",
  accent: "#6366f1",
  accentBg: "rgba(99,102,241,0.1)",
  success: "#15803d",
  successBg: "#f0fdf4",
  successText: "#15803d",
  danger: "#dc2626",
  dangerBg: "#fef2f2",
  dangerText: "#dc2626",
  dangerBorder: "#fca5a5",
  pill: "rgba(0,0,0,0.05)",
  pillActive: "#6366f1",
  segBg: "rgba(0,0,0,0.04)",
  toastSuccessBg: "#f0fdf4",
  toastSuccessText: "#15803d",
  toastErrorBg: "#fef2f2",
  toastErrorText: "#dc2626",
  modalBg: "#ffffff",
  scanOverlay: "rgba(0,0,0,0.45)",
  corner: "rgba(99,102,241,0.9)",
  glass: "rgba(255,255,255,0.88)",
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getThemeFromStorage(): ColorScheme | null {
  try {
    if (typeof localStorage !== "undefined") {
      const v = localStorage.getItem("theme");
      if (v === "dark" || v === "light") return v;
    }
  } catch {}
  return null;
}

function getLangFromStorage(): string {
  try {
    if (typeof localStorage !== "undefined") {
      const v = localStorage.getItem("i18n_lang");
      if (v && I18N[v]) return v;
    }
  } catch {}
  return "en";
}

function needsQuantity(data: ApiResponse): boolean {
  return (
    data.needs_quantity === true ||
    data.mode === "needs_quantity" ||
    data.mode === "quantity_required"
  );
}

// ─── Quantity Modal ───────────────────────────────────────────────────────────

interface QuantityModalProps {
  visible: boolean;
  productName: string | null;
  t: (k: LangKey) => string;
  C: typeof DARK;
  onSave: (qty: QuantityInfo) => void;
  onCancel: () => void;
}

function QuantityModal({ visible, productName, t, C, onSave, onCancel }: QuantityModalProps) {
  const [qty, setQty] = useState("1");
  const [unit, setUnit] = useState(UNIT_OPTIONS[0]);
  const [showUnitPicker, setShowUnitPicker] = useState(false);

  const handleSave = useCallback(() => {
    const parsed = parseInt(qty, 10);
    onSave({
      product_quantity: isNaN(parsed) || parsed < 1 ? 1 : parsed,
      product_quantity_unit: unit,
    });
  }, [qty, unit, onSave]);

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onCancel}
    >
      <TouchableWithoutFeedback onPress={onCancel}>
        <View style={qStyles.backdrop} />
      </TouchableWithoutFeedback>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={qStyles.kav}
        pointerEvents="box-none"
      >
        <View style={[qStyles.sheet, { backgroundColor: C.modalBg, borderColor: C.border }]}>
          {/* Handle */}
          <View style={[qStyles.handle, { backgroundColor: C.border }]} />

          {/* Badge */}
          <View style={[qStyles.badge, { borderColor: C.accent, backgroundColor: C.accentBg }]}>
            <Text style={[qStyles.badgeText, { color: C.accent }]}>{t("quantityRequired")}</Text>
          </View>

          <Text style={[qStyles.title, { color: C.text }]}>{t("quantityModalTitle")}</Text>
          <Text style={[qStyles.subtitle, { color: C.textSub }]}>
            {t("quantityModalSubtitle")}{" "}
            <Text style={{ fontWeight: "700", color: C.text }}>{productName || "?"}</Text>
          </Text>

          <View style={qStyles.row}>
            {/* Quantity input */}
            <View style={qStyles.qtyCol}>
              <Text style={[qStyles.fieldLabel, { color: C.textMuted }]}>{t("quantityLabel")}</Text>
              <View style={[qStyles.inputWrap, { backgroundColor: C.surfaceAlt, borderColor: C.border }]}>
                <TextInput
                  style={[qStyles.qtyInput, { color: C.text }]}
                  value={qty}
                  onChangeText={setQty}
                  keyboardType="number-pad"
                  maxLength={6}
                  selectTextOnFocus
                  placeholderTextColor={C.textMuted}
                />
                <View style={qStyles.spinners}>
                  <Pressable
                    style={({ pressed }) => [qStyles.spinBtn, pressed && { opacity: 0.6 }]}
                    onPress={() => {
                      const n = parseInt(qty, 10);
                      setQty(String(isNaN(n) ? 2 : n + 1));
                    }}
                  >
                    <Text style={[qStyles.spinText, { color: C.textSub }]}>▲</Text>
                  </Pressable>
                  <Pressable
                    style={({ pressed }) => [qStyles.spinBtn, pressed && { opacity: 0.6 }]}
                    onPress={() => {
                      const n = parseInt(qty, 10);
                      setQty(String(isNaN(n) || n <= 1 ? 1 : n - 1));
                    }}
                  >
                    <Text style={[qStyles.spinText, { color: C.textSub }]}>▼</Text>
                  </Pressable>
                </View>
              </View>
            </View>

            {/* Unit picker */}
            <View style={qStyles.unitCol}>
              <Text style={[qStyles.fieldLabel, { color: C.textMuted }]}>{t("unitLabel")}</Text>
              <Pressable
                style={[qStyles.unitBtn, { backgroundColor: C.surfaceAlt, borderColor: showUnitPicker ? C.accent : C.border }]}
                onPress={() => setShowUnitPicker((p) => !p)}
              >
                <Text style={[qStyles.unitBtnText, { color: C.text }]}>{unit}</Text>
                <Text style={[qStyles.unitChevron, { color: C.textSub }]}>
                  {showUnitPicker ? "▲" : "▼"}
                </Text>
              </Pressable>
            </View>
          </View>

          {/* Unit dropdown */}
          {showUnitPicker && (
            <View style={[qStyles.dropdown, { backgroundColor: C.surfaceAlt, borderColor: C.border }]}>
              <ScrollView style={{ maxHeight: 180 }} showsVerticalScrollIndicator={false}>
                {UNIT_OPTIONS.map((u) => (
                  <Pressable
                    key={u}
                    style={({ pressed }) => [
                      qStyles.dropItem,
                      { borderBottomColor: C.border },
                      u === unit && { backgroundColor: C.accentBg },
                      pressed && { opacity: 0.7 },
                    ]}
                    onPress={() => {
                      setUnit(u);
                      setShowUnitPicker(false);
                    }}
                  >
                    <Text style={[qStyles.dropItemText, { color: u === unit ? C.accent : C.text }]}>
                      {u}
                    </Text>
                  </Pressable>
                ))}
              </ScrollView>
            </View>
          )}

          {/* Buttons */}
          <Pressable
            style={({ pressed }) => [
              qStyles.saveBtn,
              { backgroundColor: "#4a7c59" },
              pressed && { opacity: 0.85 },
            ]}
            onPress={handleSave}
          >
            <Text style={qStyles.saveBtnText}>{t("quantityModalSave")}</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              qStyles.cancelBtn,
              { backgroundColor: C.surfaceAlt, borderColor: C.border },
              pressed && { opacity: 0.75 },
            ]}
            onPress={onCancel}
          >
            <Text style={[qStyles.cancelBtnText, { color: C.textSub }]}>{t("quantityModalCancel")}</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const qStyles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.55)",
  },
  kav: {
    flex: 1,
    justifyContent: "flex-end",
  },
  sheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    paddingHorizontal: 22,
    paddingTop: 14,
    paddingBottom: 40,
    gap: 14,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 6,
  },
  badge: {
    alignSelf: "flex-start",
    borderWidth: 1,
    borderRadius: 20,
    paddingVertical: 5,
    paddingHorizontal: 12,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.8,
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: 14,
    lineHeight: 20,
  },
  row: {
    flexDirection: "row",
    gap: 12,
    marginTop: 4,
  },
  qtyCol: { flex: 1 },
  unitCol: { flex: 1 },
  fieldLabel: {
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 0.6,
    marginBottom: 6,
  },
  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
  },
  qtyInput: {
    flex: 1,
    paddingVertical: 14,
    paddingHorizontal: 14,
    fontSize: 16,
    fontWeight: "500",
  },
  spinners: {
    paddingRight: 6,
    gap: 2,
  },
  spinBtn: {
    padding: 4,
  },
  spinText: {
    fontSize: 10,
  },
  unitBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
  },
  unitBtnText: {
    fontSize: 16,
    fontWeight: "500",
  },
  unitChevron: {
    fontSize: 11,
    marginLeft: 8,
  },
  dropdown: {
    borderRadius: 12,
    borderWidth: 1,
    overflow: "hidden",
    marginTop: -6,
  },
  dropItem: {
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  dropItemText: {
    fontSize: 15,
    fontWeight: "500",
  },
  saveBtn: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: 4,
  },
  saveBtnText: {
    color: "#fff",
    fontSize: 15,
    fontWeight: "700",
  },
  cancelBtn: {
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 14,
    alignItems: "center",
  },
  cancelBtnText: {
    fontSize: 15,
    fontWeight: "600",
  },
});

// ─── Main Scanner ─────────────────────────────────────────────────────────────

export default function Scanner() {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { jwtToken, clearSession } = useAuthSession();

  // Route params from web navigation (?wishlist=true&count=1&text=...)
  const routeWishList = route.params?.wishList === "true" || route.params?.wishList === true;
  const routeCount = parseInt(route.params?.count ?? "1", 10) || 1;
  const routeText = route.params?.text ?? "";

  // Theme & i18n — read from localStorage (injected by WebView bridge) or system
  const [colorScheme, setColorScheme] = useState<ColorScheme>(() => {
    const stored = getThemeFromStorage();
    if (stored) return stored;
    return Appearance.getColorScheme() === "light" ? "light" : "dark";
  });
  const lang = getLangFromStorage();
  const C = colorScheme === "light" ? LIGHT : DARK;
  const t = useCallback((k: LangKey) => (I18N[lang] ?? I18N.en)[k] ?? I18N.en[k], [lang]);

  // Listen for system theme changes as fallback
  useEffect(() => {
    const stored = getThemeFromStorage();
    if (stored) return;
    const sub = Appearance.addChangeListener(({ colorScheme: cs }) => {
      setColorScheme(cs === "light" ? "light" : "dark");
    });
    return () => sub.remove();
  }, []);

  const [permission, requestPermission] = useCameraPermissions();
  const [scannerMode, setScannerMode] = useState<ScannerMode>("auto");
  const [manualTab, setManualTab] = useState<ManualTab>("name");

  // Auto scan state
  const [scanned, setScanned] = useState(false);
  const [ean, setEan] = useState("");
  const [datatype, setDatatype] = useState("");

  // Manual state
  const [manualName, setManualName] = useState(routeText);
  const [manualBarcode, setManualBarcode] = useState("");
  const [count, setCount] = useState(routeCount);

  const [sending, setSending] = useState(false);

  // Quantity modal
  const [qtyModal, setQtyModal] = useState<{
    visible: boolean;
    productName: string | null;
    pendingPayload: Parameters<typeof addEanToList>[1] | null;
    pendingAction: InventoryAction;
  }>({
    visible: false,
    productName: null,
    pendingPayload: null,
    pendingAction: "add",
  });

  // Toast
  const [toast, setToast] = useState<{ message: string; success: boolean } | null>(null);
  const toastOpacity = useRef(new Animated.Value(0)).current;
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = useCallback(
    (success: boolean, message: string) => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
      setToast({ message, success });
      toastOpacity.setValue(0);
      Animated.timing(toastOpacity, { toValue: 1, duration: 180, useNativeDriver: true }).start();
      toastTimer.current = setTimeout(() => {
        Animated.timing(toastOpacity, { toValue: 0, duration: 280, useNativeDriver: true }).start(
          () => setToast(null)
        );
      }, 2400);
    },
    [toastOpacity]
  );

  const resetAutoScan = useCallback(() => {
    setScanned(false);
    setEan("");
    setDatatype("");
    setCount(1);
  }, []);

  const goBack = useCallback(() => {
    navigation.navigate("web");
  }, [navigation]);

  // ── Core submit logic ──────────────────────────────────────────────────────

  const doSubmit = useCallback(
    async (
      payload: Parameters<typeof addEanToList>[1],
      action: InventoryAction
    ) => {
      if (sending || !jwtToken) return;
      setSending(true);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

      try {
        const data = (await addEanToList(jwtToken, payload)) as ApiResponse;

        if (needsQuantity(data)) {
          // Server needs quantity — show modal, preserving payload for retry
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          setQtyModal({
            visible: true,
            productName: data.product_name ?? payload.item_name ?? payload.ean ?? null,
            pendingPayload: payload,
            pendingAction: action,
          });
          resetAutoScan();
          return;
        }

        const itemLabel = String(data.product_name || payload.item_name || payload.ean || "item");
        const isRemove =
          String(data.operation ?? "").toLowerCase() === "delete" || action === "remove";

        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        showToast(true, `${isRemove ? t("removed") : t("added")} ${count}× ${itemLabel}`);
        resetAutoScan();
        setManualName("");
        setManualBarcode("");
        setCount(1);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "";
        if (msg.startsWith("HTTP 401")) {
          clearSession();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          showToast(false, t("sessionMissing"));
          navigation.navigate(MOBILE_LOGIN_ROUTE);
          return;
        }
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        showToast(false, t("networkError"));
        resetAutoScan();
      } finally {
        setSending(false);
      }
    },
    [clearSession, count, jwtToken, navigation, resetAutoScan, sending, showToast, t]
  );

  const submitEan = useCallback(
    async (action: InventoryAction) => {
      if (!ean) return;
      const requestedCount = Math.max(1, count);
      const countDelta = action === "remove" ? -requestedCount : requestedCount;
      await doSubmit(
        {
          ean,
          count: countDelta,
          wish_list: routeWishList ? "true" : "false",
        },
        action
      );
    },
    [doSubmit, ean, count, routeWishList]
  );

  const submitManualName = useCallback(
    async (action: InventoryAction) => {
      if (!manualName.trim()) return;
      const requestedCount = Math.max(1, count);
      const countDelta = action === "remove" ? -requestedCount : requestedCount;
      await doSubmit(
        {
          item_name: manualName.trim(),
          count: countDelta,
          wish_list: routeWishList ? "true" : "false",
        },
        action
      );
    },
    [doSubmit, manualName, count, routeWishList]
  );

  const submitManualBarcode = useCallback(
    async (action: InventoryAction) => {
      if (!manualBarcode.trim()) return;
      const requestedCount = Math.max(1, count);
      const countDelta = action === "remove" ? -requestedCount : requestedCount;
      await doSubmit(
        {
          ean: manualBarcode.trim(),
          count: countDelta,
          wish_list: routeWishList ? "true" : "false",
        },
        action
      );
    },
    [doSubmit, manualBarcode, count, routeWishList]
  );

  // Quantity modal resolution
  const handleQtyModalSave = useCallback(
    async (qty: QuantityInfo) => {
      if (!qtyModal.pendingPayload) return;
      setQtyModal((p) => ({ ...p, visible: false }));
      const newPayload = { ...qtyModal.pendingPayload, quantity_data: qty };
      await doSubmit(newPayload, qtyModal.pendingAction);
    },
    [doSubmit, qtyModal]
  );

  const handleQtyModalCancel = useCallback(() => {
    setQtyModal((p) => ({ ...p, visible: false }));
  }, []);

  // ── Permission screens ─────────────────────────────────────────────────────

  if (!permission) {
    return <View style={[s.fill, { backgroundColor: C.bg }]} />;
  }

  if (!permission.granted) {
    return (
      <View style={[s.fill, s.center, { backgroundColor: C.bg, padding: 32 }]}>
        <Text style={[s.permTitle, { color: C.text }]}>{t("noCameraTitle")}</Text>
        <Text style={[s.permBody, { color: C.textSub }]}>{t("noCameraBody")}</Text>
        <Pressable
          style={({ pressed }) => [s.permBtn, { backgroundColor: C.accent }, pressed && { opacity: 0.8 }]}
          onPress={requestPermission}
        >
          <Text style={s.permBtnText}>{t("allowCamera")}</Text>
        </Pressable>
      </View>
    );
  }

  // ── Layout ─────────────────────────────────────────────────────────────────

  const isWishList = routeWishList;
  const listLabel = isWishList ? t("wishlist") : t("inventory");

  return (
    <View style={[s.fill, { backgroundColor: C.bg }]}>
      {/* ── HEADER ── */}
      <View style={[s.header, { borderBottomColor: C.border }]}>
        <Pressable
          style={({ pressed }) => [s.backBtn, { backgroundColor: C.surfaceAlt }, pressed && { opacity: 0.7 }]}
          onPress={goBack}
        >
          <Text style={[s.backBtnText, { color: C.textSub }]}>{t("back")}</Text>
        </Pressable>

        <View style={s.headerCenter}>
          <Text style={[s.headerTitle, { color: C.text }]}>{t("title")}</Text>
          <View style={[s.listBadge, { backgroundColor: isWishList ? C.accentBg : C.pill }]}>
            <Text style={[s.listBadgeText, { color: isWishList ? C.accent : C.textSub }]}>
              {listLabel}
            </Text>
          </View>
        </View>

        {/* Mode toggle */}
        <View style={[s.modePill, { backgroundColor: C.segBg }]}>
          {(["auto", "manual"] as ScannerMode[]).map((m) => (
            <Pressable
              key={m}
              style={({ pressed }) => [
                s.modePillItem,
                scannerMode === m && { backgroundColor: C.accent },
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => setScannerMode(m)}
            >
              <Text
                style={[
                  s.modePillText,
                  { color: scannerMode === m ? "#fff" : C.textSub },
                ]}
              >
                {m === "auto" ? t("auto") : t("manual")}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* ── AUTO MODE ── */}
      {scannerMode === "auto" && (
        <View style={s.fill}>
          {/* Camera */}
          <View style={[s.cameraWrap, { borderColor: C.border }]}>
            <CameraView
              style={StyleSheet.absoluteFillObject}
              barcodeScannerSettings={{ barcodeTypes: ["ean13", "ean8"] }}
              onBarcodeScanned={
                scanned
                  ? undefined
                  : ({ type, data }) => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setDatatype(type);
                      setEan(data);
                      setScanned(true);
                    }
              }
            />

            {/* Corner guides */}
            {!scanned && (
              <>
                <View style={[s.overlay, { backgroundColor: C.scanOverlay }]} />
                <View style={s.cutout} />
                {/* Corner marks */}
                {[
                  { top: "25%", left: "10%", borderTopWidth: 3, borderLeftWidth: 3 },
                  { top: "25%", right: "10%", borderTopWidth: 3, borderRightWidth: 3 },
                  { bottom: "45%", left: "10%", borderBottomWidth: 3, borderLeftWidth: 3 },
                  { bottom: "45%", right: "10%", borderBottomWidth: 3, borderRightWidth: 3 },
                ].map((style, i) => (
                  <View
                    key={i}
                    style={[
                      s.corner,
                      style as any,
                      { borderColor: C.corner },
                    ]}
                  />
                ))}
                <Text style={[s.scanHint, { backgroundColor: C.glass, color: C.text }]}>
                  {t("pointCamera")}
                </Text>
              </>
            )}
          </View>

          {/* Bottom sheet after scan */}
          {scanned && (
            <View style={[s.sheet, { backgroundColor: C.surface, borderColor: C.border }]}>
              <View style={[s.sheetHandle, { backgroundColor: C.border }]} />

              <View style={s.eanRow}>
                <View>
                  <Text style={[s.eanType, { color: C.textMuted }]}>
                    {datatype.toUpperCase()}
                  </Text>
                  <Text style={[s.eanValue, { color: C.text }]}>{ean}</Text>
                </View>
                <Pressable
                  style={({ pressed }) => [
                    s.abortBtn,
                    { backgroundColor: C.surfaceAlt, borderColor: C.border },
                    pressed && { opacity: 0.7 },
                  ]}
                  disabled={sending}
                  onPress={() => {
                    Haptics.selectionAsync();
                    resetAutoScan();
                  }}
                >
                  <Text style={[s.abortBtnText, { color: C.textSub }]}>{t("abort")}</Text>
                </Pressable>
              </View>

              {/* Count stepper */}
              <View style={s.stepperRow}>
                <Text style={[s.stepperLabel, { color: C.textSub }]}>{t("units")}</Text>
                <View style={[s.stepper, { backgroundColor: C.surfaceAlt }]}>
                  <Pressable
                    style={({ pressed }) => [
                      s.stepBtn,
                      pressed && { backgroundColor: C.pill },
                      count <= 1 && { opacity: 0.3 },
                    ]}
                    disabled={count <= 1}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setCount((p) => Math.max(1, p - 1));
                    }}
                  >
                    <Text style={[s.stepBtnText, { color: C.text }]}>−</Text>
                  </Pressable>
                  <Text style={[s.stepCount, { color: C.text }]}>{count}</Text>
                  <Pressable
                    style={({ pressed }) => [s.stepBtn, pressed && { backgroundColor: C.pill }]}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setCount((p) => p + 1);
                    }}
                  >
                    <Text style={[s.stepBtnText, { color: C.text }]}>+</Text>
                  </Pressable>
                </View>
              </View>

              {/* Action buttons */}
              <View style={s.actions}>
                <Pressable
                  style={({ pressed }) => [
                    s.btnPrimary,
                    { backgroundColor: C.accent },
                    pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                    sending && { opacity: 0.5 },
                  ]}
                  disabled={sending}
                  onPress={() => submitEan("add")}
                >
                  <Text style={s.btnPrimaryText}>
                    {sending ? t("working") : `${t("addBtn")} ${count}`}
                  </Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [
                    s.btnDanger,
                    { backgroundColor: C.dangerBg, borderColor: C.dangerBorder },
                    pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                    sending && { opacity: 0.5 },
                  ]}
                  disabled={sending}
                  onPress={() => submitEan("remove")}
                >
                  <Text style={[s.btnDangerText, { color: C.dangerText }]}>
                    {sending ? t("working") : `${t("removeBtn")} ${count}`}
                  </Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      )}

      {/* ── MANUAL MODE ── */}
      {scannerMode === "manual" && (
        <KeyboardAvoidingView
          behavior={Platform.OS === "ios" ? "padding" : "height"}
          style={s.fill}
        >
          <ScrollView
            style={s.fill}
            contentContainerStyle={s.manualScroll}
            keyboardShouldPersistTaps="handled"
          >
            <View style={[s.card, { backgroundColor: C.surface, borderColor: C.border }]}>
              {/* Tab switcher */}
              <View style={[s.tabs, { backgroundColor: C.segBg }]}>
                {(["name", "barcode"] as ManualTab[]).map((tab) => (
                  <Pressable
                    key={tab}
                    style={({ pressed }) => [
                      s.tabItem,
                      manualTab === tab && [s.tabItemActive, { backgroundColor: C.accent }],
                      pressed && { opacity: 0.8 },
                    ]}
                    onPress={() => setManualTab(tab)}
                  >
                    <Text
                      style={[
                        s.tabText,
                        { color: manualTab === tab ? "#fff" : C.textSub },
                      ]}
                    >
                      {tab === "name" ? t("byName") : t("byBarcode")}
                    </Text>
                  </Pressable>
                ))}
              </View>

              {/* Name tab */}
              {manualTab === "name" && (
                <View style={s.fieldGroup}>
                  <Text style={[s.fieldLabel, { color: C.textSub }]}>{t("itemName")}</Text>
                  <TextInput
                    style={[
                      s.textInput,
                      {
                        backgroundColor: C.surfaceAlt,
                        borderColor: manualName ? C.borderFocus : C.border,
                        color: C.text,
                      },
                    ]}
                    placeholder={t("namePlaceholder")}
                    placeholderTextColor={C.textMuted}
                    value={manualName}
                    onChangeText={setManualName}
                    autoCapitalize="none"
                    returnKeyType="done"
                  />
                </View>
              )}

              {/* Barcode tab */}
              {manualTab === "barcode" && (
                <View style={s.fieldGroup}>
                  <Text style={[s.fieldLabel, { color: C.textSub }]}>{t("barcodeLabel")}</Text>
                  <TextInput
                    style={[
                      s.textInput,
                      {
                        backgroundColor: C.surfaceAlt,
                        borderColor: manualBarcode ? C.borderFocus : C.border,
                        color: C.text,
                        fontVariant: ["tabular-nums"],
                        letterSpacing: 1,
                      },
                    ]}
                    placeholder={t("barcodePlaceholder")}
                    placeholderTextColor={C.textMuted}
                    value={manualBarcode}
                    onChangeText={(v) => setManualBarcode(v.replace(/\D/g, "").slice(0, 14))}
                    keyboardType="number-pad"
                    maxLength={14}
                    returnKeyType="done"
                  />
                  <Text style={[s.fieldHint, { color: C.textMuted }]}>
                    {manualBarcode.length} / 14 {t("digits")}
                  </Text>
                </View>
              )}

              {/* Count stepper */}
              <View style={s.stepperRow}>
                <Text style={[s.stepperLabel, { color: C.textSub }]}>{t("units")}</Text>
                <View style={[s.stepper, { backgroundColor: C.surfaceAlt }]}>
                  <Pressable
                    style={({ pressed }) => [
                      s.stepBtn,
                      pressed && { backgroundColor: C.pill },
                      count <= 1 && { opacity: 0.3 },
                    ]}
                    disabled={count <= 1}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setCount((p) => Math.max(1, p - 1));
                    }}
                  >
                    <Text style={[s.stepBtnText, { color: C.text }]}>−</Text>
                  </Pressable>
                  <Text style={[s.stepCount, { color: C.text }]}>{count}</Text>
                  <Pressable
                    style={({ pressed }) => [s.stepBtn, pressed && { backgroundColor: C.pill }]}
                    onPress={() => {
                      Haptics.selectionAsync();
                      setCount((p) => p + 1);
                    }}
                  >
                    <Text style={[s.stepBtnText, { color: C.text }]}>+</Text>
                  </Pressable>
                </View>
              </View>

              {/* Action buttons */}
              <View style={s.actions}>
                {(() => {
                  const isValid =
                    manualTab === "name"
                      ? manualName.trim().length > 0
                      : manualBarcode.length >= 8;
                  const onAdd = () =>
                    manualTab === "name" ? submitManualName("add") : submitManualBarcode("add");
                  const onRemove = () =>
                    manualTab === "name" ? submitManualName("remove") : submitManualBarcode("remove");

                  return (
                    <>
                      <Pressable
                        style={({ pressed }) => [
                          s.btnPrimary,
                          { backgroundColor: isValid ? C.accent : C.pill },
                          pressed && isValid && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                          (!isValid || sending) && { opacity: 0.5 },
                        ]}
                        disabled={!isValid || sending}
                        onPress={onAdd}
                      >
                        <Text style={s.btnPrimaryText}>
                          {sending ? t("working") : `${t("addBtn")} ${count}`}
                        </Text>
                      </Pressable>
                      <Pressable
                        style={({ pressed }) => [
                          s.btnDanger,
                          {
                            backgroundColor: isValid ? C.dangerBg : C.pill,
                            borderColor: isValid ? C.dangerBorder : C.border,
                          },
                          pressed && isValid && { opacity: 0.85, transform: [{ scale: 0.98 }] },
                          (!isValid || sending) && { opacity: 0.5 },
                        ]}
                        disabled={!isValid || sending}
                        onPress={onRemove}
                      >
                        <Text
                          style={[
                            s.btnDangerText,
                            { color: isValid ? C.dangerText : C.textMuted },
                          ]}
                        >
                          {sending ? t("working") : `${t("removeBtn")} ${count}`}
                        </Text>
                      </Pressable>
                    </>
                  );
                })()}
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      )}

      {/* ── TOAST ── */}
      {toast && (
        <Animated.View
          style={[
            s.toast,
            toast.success
              ? { backgroundColor: C.toastSuccessBg }
              : { backgroundColor: C.toastErrorBg },
            { opacity: toastOpacity },
          ]}
          pointerEvents="none"
        >
          <Text style={{ fontSize: 15 }}>{toast.success ? "✓" : "✕"}</Text>
          <Text
            style={[
              s.toastText,
              { color: toast.success ? C.toastSuccessText : C.toastErrorText },
            ]}
          >
            {toast.message}
          </Text>
        </Animated.View>
      )}

      {/* ── QUANTITY MODAL ── */}
      <QuantityModal
        visible={qtyModal.visible}
        productName={qtyModal.productName}
        t={t}
        C={C}
        onSave={handleQtyModalSave}
        onCancel={handleQtyModalCancel}
      />
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  fill: { flex: 1 },
  center: { justifyContent: "center", alignItems: "center" },

  // Permission
  permTitle: { fontSize: 22, fontWeight: "700", marginBottom: 8 },
  permBody: { fontSize: 15, textAlign: "center", marginBottom: 24 },
  permBtn: {
    paddingVertical: 13,
    paddingHorizontal: 28,
    borderRadius: 14,
  },
  permBtnText: { color: "#fff", fontSize: 15, fontWeight: "700" },

  // Header
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: Platform.OS === "ios" ? 56 : 16,
    paddingBottom: 12,
    paddingHorizontal: 16,
    gap: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: {
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderRadius: 10,
  },
  backBtnText: { fontSize: 13, fontWeight: "600" },
  headerCenter: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  headerTitle: { fontSize: 16, fontWeight: "700" },
  listBadge: {
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  listBadgeText: { fontSize: 11, fontWeight: "600" },

  // Mode pill
  modePill: {
    flexDirection: "row",
    borderRadius: 10,
    padding: 3,
    gap: 2,
  },
  modePillItem: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 8,
  },
  modePillText: { fontSize: 12, fontWeight: "600" },

  // Camera
  cameraWrap: {
    flex: 1,
    margin: 16,
    borderRadius: 20,
    overflow: "hidden",
    borderWidth: 1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  cutout: {
    position: "absolute",
    top: "25%",
    left: "10%",
    right: "10%",
    bottom: "45%",
    backgroundColor: "transparent",
  },
  corner: {
    position: "absolute",
    width: 24,
    height: 24,
    borderColor: "white",
  },
  scanHint: {
    position: "absolute",
    bottom: 20,
    alignSelf: "center",
    fontSize: 13,
    fontWeight: "600",
    paddingVertical: 7,
    paddingHorizontal: 14,
    borderRadius: 20,
    overflow: "hidden",
  },

  // Bottom sheet (auto mode after scan)
  sheet: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    borderBottomWidth: 0,
    paddingTop: 12,
    paddingBottom: Platform.OS === "ios" ? 36 : 24,
    paddingHorizontal: 20,
    gap: 16,
  },
  sheetHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: "center",
    marginBottom: 4,
  },
  eanRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  eanType: {
    fontSize: 11,
    fontWeight: "600",
    letterSpacing: 1,
    marginBottom: 2,
  },
  eanValue: {
    fontSize: 22,
    fontWeight: "700",
    letterSpacing: 1.5,
    fontVariant: ["tabular-nums"],
  },
  abortBtn: {
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 1,
  },
  abortBtnText: { fontSize: 13, fontWeight: "600" },

  // Stepper
  stepperRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  stepperLabel: { fontSize: 14, fontWeight: "500" },
  stepper: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 12,
    gap: 2,
    padding: 3,
  },
  stepBtn: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  stepBtnText: { fontSize: 22, fontWeight: "500", lineHeight: 28 },
  stepCount: {
    minWidth: 36,
    textAlign: "center",
    fontSize: 18,
    fontWeight: "700",
    fontVariant: ["tabular-nums"],
  },

  // Buttons
  actions: { flexDirection: "row", gap: 10 },
  btnPrimary: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 14,
    alignItems: "center",
  },
  btnPrimaryText: { fontSize: 15, fontWeight: "700", color: "#fff" },
  btnDanger: {
    flex: 1,
    paddingVertical: 15,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
  },
  btnDangerText: { fontSize: 15, fontWeight: "700" },

  // Manual
  manualScroll: { padding: 16, paddingTop: 12 },
  card: {
    borderRadius: 20,
    borderWidth: 1,
    padding: 16,
    gap: 16,
  },
  tabs: {
    flexDirection: "row",
    borderRadius: 12,
    padding: 3,
    gap: 3,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 9,
    borderRadius: 10,
    alignItems: "center",
  },
  tabItemActive: {},
  tabText: { fontSize: 13, fontWeight: "600" },

  fieldGroup: { gap: 6 },
  fieldLabel: { fontSize: 13, fontWeight: "600" },
  textInput: {
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 13,
    paddingHorizontal: 14,
    fontSize: 15,
  },
  fieldHint: { fontSize: 11, textAlign: "right", marginTop: 2 },

  // Toast
  toast: {
    position: "absolute",
    top: Platform.OS === "ios" ? 110 : 72,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 11,
    paddingHorizontal: 16,
    borderRadius: 14,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 5,
    maxWidth: "88%",
  },
  toastText: { fontSize: 13, fontWeight: "600", flexShrink: 1 },
});